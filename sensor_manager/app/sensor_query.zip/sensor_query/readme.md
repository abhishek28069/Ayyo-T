# Sensor Query Service 

## Starting Instructions

- `pip install -r requirements.txt`
- `python3 query_server.py`

## Documentation Link
- This doc can be used by application developer for developing sample application
- [API documentation link](https://documenter.getpostman.com/view/8017219/2s93Xwz4Q9)