import { useState, useEffect } from "react";
import "./App.css";
import bindings from "./bindings.json";
import { Switch } from "@mantine/core";

let nodes = [];
const setNodes = () => {
  Object.entries(bindings).forEach(([key, val]) => {
    // console.log(key,val)
    val.forEach((node) => {
      nodes.push(node);
    });
  });
};

function App() {
  const [data, setData] = useState({});
  const [ac, setAc] = useState(true);
  const [fan, setFan] = useState(true);
  const [light, setLight] = useState(true);

  const getButtons = () => {
    return (
      <div>
        <Switch size="lg" label="Light" defaultValue={light} disabled={true} />
        <Switch size="lg" label="Fan" defaultValue={fan} disabled={true} />
        <Switch size="lg" label="AC" defaultValue={ac} disabled={true} />
      </div>
    );
  };

  useEffect(() => {
    const fetchData = async () => {
      const newData = {};

      for (const category in bindings) {
        for (const sensor of bindings[category]) {
          const response = await fetch(`http://localhost:3000/sensor/data/${sensor}`);
          const result = await response.json();
          newData[sensor] = result;
          console.log(result);
        }
      }

      setData(newData);
    };

    const feature1 = (node) => {
      if (node.startsWith("SR-AQ")) {
        let node_data = data[node]["data"]["field1"];
        if (node_data > 500) {
          setAc(true);
          setFan(true);
        } else {
          setAc(false);
          setFan(false);
        }
      } else if (node.startsWith("SR-OC")) {
        let node_data = data[node]["data"]["field5"];
        if (node_data > 29.5) {
          setAc(true);
          setFan(true);
        } else {
          setAc(false);
          setFan(false);
        }
      }
    };

    const feature2 = (node) => {
      let aq, sl, em;
      if (node.startsWith("SR-AQ")) {
        aq = data[node]["data"]["field1"];
        // 500
      }
      if (node.startsWith("SR-OC")) {
        sl = data[node]["data"]["field5"];
        // 29.5
      }
      if (node.startsWith("SR-AC")) {
        em = data[node]["data"]["field1"];
        // 27.5
      }

      if (aq > 500 && em <= 27.5) {
        setFan(false);
        setAc(true);
        setLight(true);
      }
      if (aq > 500 && em > 27.5) {
        setFan(false);
        setAc(false);
        setLight(true);
      }
      if (sl <= 29.5 && em <= 27.5) {
        setFan(true);
        setAc(true);
        setLight(false);
      }
      if (sl <= 29.5 && em > 27.5) {
        setFan(true);
        setAc(false);
        setLight(false);
      }
      if (sl <= 29.5 && em <= 27.5 && aq <= 500) {
        setFan(true);
        setAc(true);
        setLight(true);
      }
    };

    const intervalId = setInterval(() => {
      fetchData();
      for (const key in data) {
        feature1(key);
        feature2(key);
      }
    }, 5000);

    // fetchData();

    return () => clearInterval(intervalId);
  }, []);

  return (
    <div>
      {getButtons()}
      {Object.entries(data).map(([key, value]) => {
        return (
          <div>
            <p>{key}</p>
            <p>{key.includes("OC") ? value.data.field5 : value.data.field1}</p>
          </div>
        );
      })}
    </div>
  );
}

export default App;
