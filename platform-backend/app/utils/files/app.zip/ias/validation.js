function validation(buffer)
{
    const fs = require('fs');
    const path = require("path");

    const contractkeys_data = fs.readFileSync(path.resolve(__dirname, 'resources/contract_keys.txt'), 'utf-8');
    const contract_keys = contractkeys_data.split('\n');

    console.log(contract_keys)
    // actual reading data
    const jsonData = JSON.parse(buffer.toString());
    //const jsonData = JSON.parse(fs.readFileSync(path.resolve(__dirname, 'resources\\appconfig.json'), 'utf-8'));


    const hasAllKeys = contract_keys.every(key => key in jsonData);
    let message=''

    if (hasAllKeys) {
    console.log("The contract.JSON file has all of the specified keys.");
    } else {
        message="The contract.JSON file is missing at least one of the specified keys."
        console.log("The contract.JSON file is missing at least one of the specified keys.");
        return ["False",message]
    }

    /'Null check validation'/
    if (jsonData.name == '')
       { 
            message="Invalid Contract! Name of the application missing"
            console.log(message)
            return ["False",message]
        }

    if (jsonData.cmd == "")
        {
            message="Invalid Contract! Cmd of the application missing"
            console.log(message)
            return ["False",message]
        }

    if (jsonData.env == "")
        {
            message="Invalid Contract! Environment of the application missing"
            console.log(message)
            return ["False",message]
        }

    if (jsonData.modules.length === 0) {
        message="Invalid Contract! Modules of the application missing"
        console.log(message)
        return ["False",message]
    }

    if (Array.isArray(jsonData.sensors) && jsonData.sensors.length > 0) {
        console.log('Valid sensors:', jsonData.sensors);
      } else {
        const message = 'Invalid Contract! Sensors of the application missing';
        console.log(message);
        return ['False', message];
      }

    const sensors = fs.readFileSync(path.resolve(__dirname, 'resources/sensor_list.txt'), 'utf-8');
    const sensors_list = sensors.split('\n');
    console.log(sensors_list)

    console.log(jsonData)
    const invalid_sensors = jsonData.sensors.filter(sensor => !sensors_list.includes(sensor));

    if (invalid_sensors.length > 0) {
        message=`The following sensor types are invalid: ${invalid_sensors.join(", ")}`;
        console.log(`The following sensor types are invalid: ${invalid_sensors.join(", ")}`);
        return ["False",message]
    }

    const invalid_controllers = jsonData.controllers.filter(controller => !sensors_list.includes(controller));


    if (invalid_controllers.length > 0) {
        message=`The following controller types are invalid: ${invalid_controllers.join(", ")}`;
        console.log(`The following sensor types are invalid: ${invalid_controllers.join(", ")}`);
        return ['False',message];
    }
    return ['True']


}   
module.exports = {
    validation
}
