# ias
* run npm install
* nodemon app.js
