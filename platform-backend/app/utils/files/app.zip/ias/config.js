// module.exports = {
//     ldap: {
//       url: 'localhost:10389',
//       bindDn: 'uid=admin,ou=system',
//       bindCredentials: 'password',
//       searchBase: 'dc=example,dc=com',
//       searchFilter: '(uid={{username}})'
//     }
//   };

//   // bindDn: 'cn=admin,dc=example,dc=com',
//   // url: 'ldap://ldap.example.com',