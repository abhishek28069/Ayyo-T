const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const multer = require('multer');
const ldap = require('ldapjs');
const crypto = require('crypto');
const cors = require("cors");

const validation =require('./validation.js');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.set("view engine", "ejs");

app.use(cors());

const storage = multer.memoryStorage();
const upload = multer({ storage });
const db = mongoose.createConnection(
  "mongodb+srv://venkatesh:Mongo21@cluster0.f18hmur.mongodb.net/db_files_storage?retryWrites=true&w=majority"
);

const fileSchema = new mongoose.Schema({
  id: Number,
  filename: String,
  data: Buffer,
});
const File = db.model("File", fileSchema);

const db_sch=mongoose.createConnection( "mongodb+srv://venkatesh:Mongo21@cluster0.f18hmur.mongodb.net/?retryWrites=true&w=majority")
const scheduler_Schema = new mongoose.Schema({
  application_id:Number,
  scheduler_info: String,
  scheduler_id: Number
});
const Scheduler = db_sch.model('Scheduler', scheduler_Schema); 

//----------------------------from here
//creating a new client at this url(localhost)
const client = ldap.createClient({
  url: ['ldap://127.0.0.1:10389', 'ldap://127.0.0.2:10389']
  });
  client.on('connectError', (err) => {
    console.log("1. Error in new connection : " + err);
    })
//
function authenticateDN(_username, _password){
  UserDn = "cn=" + _username + ",ou=users,ou=system";
    //bind to ldap server
  client.bind(UserDn, _password, (err) => {
  if(err){
    console.log("2. Error in bind connection : " + err);
  } else {
    console.log("LDAP Authentication successful");
  }
  });
  client.unbind();
}

//add a new user to LDAP
function addUser(_role, _username, _password, _email, _uid){
  UserDn = "cn=" + _username + ",ou=users,ou=system";
  //computing sha1 hash of the password
  const sha1 = crypto.createHash('sha1').update(_password).digest();
  //encoding it in base 64 format
  const base64 = sha1.toString('base64');
  const _userPassword = "{SHA}" + base64;
  const entry = {
    gn : _role,
    mail: _email,
    userPassword : _userPassword,
    sn : _username, 
    uid : _uid,
    objectclass: 'inetOrgPerson'
  };
  client.add(UserDn, entry, (err) => {
      if(err){
        console.log("Error while adding user : " + err);
      } else {
        console.log("LDAP add user successful");
      }
  });
}

    // addUser("SenReg", "SR1", "SR1pwd", 'SR1@gmail.com', 111);
    // addUser("SenReg", "SR2", "SR2pwd", 'SR2@gmail.com', 222);
    // addUser("AppDev", "AD1", "AD1pwd", 'AD1@gmail.com', 333);
    // addUser("AppDev", "AD2", "AD2pwd", 'AD2@gmail.com', 444);
    // addUser("PlaAdm", "PA1", "PA1pwd", 'PA1@gmail.com', 555);
    // addUser("PlaAdm", "PA2", "PA2pwd", 'PA2@gmail.com', 666);

    // authenticateDN("SR1", "SR1pwd");
    // authenticateDN("SR2", "SR2pwd");
    // authenticateDN("AD1", "AD1pwd");
    // authenticateDN("AD2", "AD2pwd");
    // authenticateDN("PA1", "PA1pwd");
    // authenticateDN("PA2", "PA2pwd");




    //---------------------------------till here


mongoose.connect(
    "mongodb+srv://venkatesh:Mongo21@cluster0.f18hmur.mongodb.net/db_1?retryWrites=true&w=majority",
    {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    }
  )
  .then(() => {
    console.log("Connected to MongoDB database");
  })
  .catch((error) => {
    console.log("Error connecting to MongoDB database:", error);
  });

const userSchema = new mongoose.Schema({
  role: String,
  name: String,
  email: String,
  password: String,
});
const User = mongoose.model("User", userSchema);

app.get("/", (req, res) => {
  res.render("index.ejs");
});

app.post("/login", (req, res) => {
  console.log(req.body)
  const username_ = req.body.username;
  const email_ = req.body.email;
  const pass_ = req.body.password;
  const role_=req.body.role
  console.log('user type from login...is '+role_);

  //ldap authenticate user in Active Directory
  authenticateDN(username_, pass_);
  //end of this

  //query the user data from the database
  User.findOne({ email: email_, password: pass_ ,role:role_})
    .exec()
    .then((user) => {
      if (!user) {
        // User not found
        //   console.log("User not found in the db");
        alert("User not found. Please Register");
        res.redirect("/");
      } else {
        // User found, do something with the user object
        console.log("User login success");
        res.redirect("/upload");
      }
    })
    .catch((err) => {
      // Handle error
      console.log("Error while querying the db");
    });
});

app.post("/register", (req, res) => {
  const name_ = req.body.name;
  const email_ = req.body.email;
  const pass_ = req.body.password;
  // const form = document.forms.register;
  // const radios = form.elements.exampleRadios;
  const role_ = req.body.exampleRadios;
  console.log("role is " + role_);
  const user = new User({
    role: role_,
    name: name_,
    email: email_,
    password: pass_,
  });

  //ldap add user in Active Directory
  let r_no = Math.floor(Math.random() * 100000);
  addUser(role_, name_, pass_, email_, r_no);
  //end of this 

  //send the data to the database
  user
    .save()
    .then(() => {
      console.log("New user saved to MongoDB Cloud database");
    })
    .catch((error) => {
      console.log("Error saving new user to MongoDB Cloud database:", error);
    });

  


  //if the email already exists in the database, ask them to login
  console.log(name_, email_, pass_);
  res.redirect("/");
});

app.post( "/uploadFiles",
  upload.fields([{ name: "zipFile" }, { name: "jsonFile" }]),
  async (req, res) => {
    let message = "";
    let r_no = Math.floor(Math.random() * 100000);
    console.log(r_no);
    try {
      // Save files to MongoDB
      if (
        req.files["zipFile"][0].mimetype === "application/zip" ||
        req.files["zipFile"][0].mimetype === "application/x-zip-compressed"
      ) {
      } else {
        message = "error in file format it should be .zip";
        throw message;
      }
      if (String(req.files["jsonFile"][0].originalname).includes("json")) {

        let status=validation.validation(req.files["jsonFile"][0].buffer)
        if(status[0]=='False')
        {
          message=status[1]
          throw message
        }
      } else {
        message = "error in file format it should be .json";
        throw message;
      }

      const zipFile = new File({
        id: r_no,
        filename: req.files["zipFile"][0].originalname,
        data: req.files["zipFile"][0].buffer,
      });
      console.log("succefully upload file 1");

      console.log(req.files["jsonFile"][0].mimetype);
      const jsonFile = new File({
        id: r_no,
        filename: req.files["jsonFile"][0].originalname,
        data: req.files["jsonFile"][0].buffer,
      });
      console.log("succefully upload file 1");

      await Promise.all([zipFile.save(), jsonFile.save()]);
      // Send success response
      // res.render("upload.ejs", { response: "Files uploaded successfully!" });
      //  res.render("scheduler.ejs",{applicationId:r_no});
      res.status(200).json({ success: true, applicationId: r_no });
    } catch (err) {
      console.error(err);
      // res.render("upload.ejs", { response: message });
      res.status(500).json({ success: false, message: message });
    }
  }
);

app.get("/app_developer",(req,res)=>{
  res.render("app_developer.ejs");
})

app.get("/upload", (req, res) => {
  res.render("upload.ejs", { response: "" });
});


app.post(('/scheduler'),(req, res) => {

      try{
        let r_no=Math.floor(Math.random() * 100000)
        let arr_obj=[];
        let sche_info={
          "start_date":req.body.startDate,
          "end_date":req.body.endDate,
        };
        if(req.body.monday==="monday")
        {
          let obj=
          {
            "day":"monday",
            "start_time":req.body.monday_start_time,
            "end_time":req.body.monday_end_time
          }
          arr_obj.push(obj);
        }
        if(req.body.tuesday==="tuesday")
        {
          let obj=
          {
            "day":"tuesday",
            "start_time":req.body.tuesday_start_time,
            "end_time":req.body.tuesday_end_time
          }
          arr_obj.push(obj);
        }
        if(req.body.wednesday==="wednesday")
        {
          let obj=
          {
            "day":"wednesday",
            "start_time":req.body.wednesday_start_time,
            "end_time":req.body.wednesday_end_time
          }
          arr_obj.push(obj);
        }
        if(req.body.thursday==="thursday")
        {
          let obj=
          {
            "day":"thursday",
            "start_time":req.body.thursday_start_time,
            "end_time":req.body.thursday_end_time
          }
          arr_obj.push(obj);
        }
        if(req.body.friday==="friday")
        {
          let obj=
          {
            "day":"friday",
            "start_time":req.body.friday_start_time,
            "end_time":req.body.friday_end_time
          }
          arr_obj.push(obj);
        }
        if(req.body.saturday==="saturday")
        {
          let obj=
          {
            "day":"saturday",
            "start_time":req.body.saturday_start_time,
            "end_time":req.body.saturday_end_time
          }
          arr_obj.push(obj);
        }
        if(req.body.sunday==="sunday")
        {
          let obj=
          {
            "day":"sunday",
            "start_time":req.body.sunday_start_time,
            "end_time":req.body.sunday_end_time
          }
          arr_obj.push(obj);
        }
        
        sche_info["days"]=arr_obj;
        const scheduler = new Scheduler({
          application_id:req.body.applicationId,
          scheduler_info:JSON.stringify(sche_info),
          scheduler_id:r_no
        });
        scheduler.save()
                 .then(() => {
                        console.log(" schdeuler Data saved to MongoDB Cloud database");
                          })
                  .catch((error) => {
                          console.log("Error saving schdeuler data to MongoDB Cloud database:", error);
                          });

        console.log(JSON.stringify(scheduler))
        console.log("succefully upload data");
        let message="uploaded Scheduler data successfully"
        res.render("upload.ejs",{response:message});
      }
      catch(err)
      {
        console.error(err);
      }

});

app.listen(3000, () => {
  console.log("Server listening on port 3000");
});




